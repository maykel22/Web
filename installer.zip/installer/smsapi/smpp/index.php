<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
	#	SMPP module for Sendroid Ultimate
	#	Developed by: Ynet Interactive
	#	Special thanks: Rayed Alrashed 
*/
global $LANG;
global $configverssion_id;
global $configapp_version;
global $server;

$message_id = $THIS_MESSAGE_ID;
$userID = singleMessageData($THIS_MESSAGE_ID,'customer_id');
$resellerID = userData($userID,'reseller');
$gateway_id = $THIS_MESSAGE_GATEWAY;

$customer_id = singleMessageData($THIS_MESSAGE_ID,'customer_id');
$from = singleMessageData($THIS_MESSAGE_ID,'sender_id');
$to = str_replace('+','',singleMessageData($THIS_MESSAGE_ID,'recipient'));
$message = singleMessageData($THIS_MESSAGE_ID,'message');
$type = singleMessageData($THIS_MESSAGE_ID,'type');
$duration = singleMessageData($THIS_MESSAGE_ID,'duration');
$country = singleMessageData($THIS_MESSAGE_ID,'country_id');
$pageCount = countPage($message,$type,$duration);
$cost = smsCost($to,$type,$country,$pageCount,$customer_id,$gateway_id);
$media = singleMessageData($THIS_MESSAGE_ID,'media');
$type = singleMessageData($THIS_MESSAGE_ID,'type');

//gateway authentication stuffs		
$base_url = trim(smsGatewayData($gateway_id,'base_url')); 
$USERNAME = trim(smsGatewayData($gateway_id,'username')); 
$PASSWORD = trim(smsGatewayData($gateway_id,'password')); 
$port = smsGatewayData($gateway_id,'param1_value'); 
$success_word = $result = 'OK';
require_once 'sendroid.smpp.php';
$s = new smpp();
$s->debug=0;
$s->open($base_url, $port, $USERNAME, $PASSWORD);
if($type=='unicode') {
	$utf = true;
	$message = iconv('Windows-1256','UTF-16BE',$message);
	$sent = $s->send_long($from, $to, $message, $utf);	
} elseif($type=='flash') {
	$utf = 0;
	$flash = true;
	$sent = $s->send_long($from, $to, $message, $utf, $flash);	
} else {
	$sent = $s->send_long($from, $to, $message);
}
$s->close();

//if((stripos(strtolower($result),strtolower($success_word)) !== false)) {
if($sent) {	
   $status = 'sent';
	mysqli_query($server, "UPDATE  `messagedetails` SET `status` = 'sent', 
	`cost` = '$cost', 
	`dlr` = 'sent' WHERE `id` = '$message_id'");	
} else {
	  $status = 'Connection to server failed';
	  $status = mysqli_real_escape_string($server,$status);
	  mysqli_query($server, "UPDATE  `messagedetails` SET `status` = 'failed', 
	  `cost` = '0', 
	  `dlr` = 'failed', 
	  `notice` = '$status' WHERE `id` = '$message_id'");
  }
?>