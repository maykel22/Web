<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
	#	SMSKit WhatsApp module for Sendroid Ultimate
	#	Developed by: SMSKit.net
	#	Special thanks: Chuka
*/
global $LANG;
global $configverssion_id;
global $configapp_version;
global $server;

$message_id = $THIS_MESSAGE_ID;
$userID = singleMessageData($THIS_MESSAGE_ID,'customer_id');
$resellerID = userData($userID,'reseller');
$gateway_id = $THIS_MESSAGE_GATEWAY;

$customer_id = singleMessageData($THIS_MESSAGE_ID,'customer_id');
$from = singleMessageData($THIS_MESSAGE_ID,'sender_id');
$to = str_replace('+','',singleMessageData($THIS_MESSAGE_ID,'recipient'));
$message = singleMessageData($THIS_MESSAGE_ID,'message');
$type = singleMessageData($THIS_MESSAGE_ID,'type');
$duration = singleMessageData($THIS_MESSAGE_ID,'duration');
$country = singleMessageData($THIS_MESSAGE_ID,'country_id');
$pageCount = countPage($message,$type,$duration);
$cost = smsCost($to,$type,$country,$pageCount,$customer_id,$gateway_id);
$media = singleMessageData($THIS_MESSAGE_ID,'media');
$type = singleMessageData($THIS_MESSAGE_ID,'type');

//gateway authentication stuffs		
$api_key = trim(smsGatewayData($gateway_id,'username')); 
$token = trim(smsGatewayData($gateway_id,'password')); 
$route = smsGatewayData($gateway_id,'param1_value'); 
if(!is_numeric($route)) { 
	$route = 0;
}

$success_word = 'queued';
$url = "https://account.smskit.net/smsAPI?sendsms&apikey=".$api_key."&apitoken=".$token."&type=whatsapp&from=".$from."&to=".$to."&text=".$message."&route=".$route."&file=".$media;
$options = "";
// Send a request
$result = file_get_contents($url, false, NULL);
if((stripos(strtolower($result),strtolower($success_word)) !== false)) {
   $status = 'sent';
	mysqli_query($server, "UPDATE  `messagedetails` SET `status` = 'sent', 
	`cost` = '$cost', 
	`dlr` = 'sent' WHERE `id` = '$message_id'");	
} else {
	$status = $result;
	$status = mysqli_real_escape_string($server,$status);
	mysqli_query($server, "UPDATE  `messagedetails` SET `status` = 'failed', 
	  `cost` = '0', 
	  `dlr` = 'failed', 
	  `notice` = '$status' WHERE `id` = '$message_id'");
 }
?>