<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
global $server;
if(isset($_REQUEST['read_notice'])) {
	$read_notice =  mysqli_real_escape_string($server,$_REQUEST['read_notice']);	
	mysqli_query($server, "UPDATE  `notice` SET  `is_seen` =  '1' WHERE `user_id` = '$read_notice' LIMIT 6");
	echo 'ok';
	die();
}