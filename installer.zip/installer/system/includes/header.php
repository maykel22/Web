<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
if(getUser() > 0) {
//Initiate Global Variables 
$userID = getUser();	
$resellerID = getReseller();	
global $userID; global $LANG; global $server;	
# ---------------------------------------------------------------------
#  Add all header scripts here
#----------------------------------------------------------------------
global $hooks;
$hooks->do_action('HeaderEvent');
?>
<!DOCTYPE html>
<html lang="en">
<head>
        <!-- Title -->
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
        <meta charset="UTF-8">
        <meta name="author" content="Ynet Interactive" />
        <meta name="msapplication-TileColor" content="<?=getSetting('headerColor')?>">
		<meta name="theme-color" content="<?=getSetting('headerColor')?>">
		<meta name="msapplication-TileColor" content="<?=getSetting('headerColor')?>">
        <!-- Styles -->
        <link type="text/css" rel="stylesheet" href="assets/plugins/materialize/css/materialize.min.css"/>
		<link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="//fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="assets/plugins/material-preloader/css/materialPreloader.min.css" rel="stylesheet">  
        <link href="assets/plugins/simditor/styles/simditor.css" rel="stylesheet"/>  
		<link href="assets/plugins/sweetalert/sweetalert.css" rel="stylesheet" type="text/css"/> 
        <link href="assets/plugins/morris.js/morris.css" rel="stylesheet" type="text/css"/> 
        <link href="assets/plugins/select2/css/select2.css" rel="stylesheet"> 
        <link href="assets/plugins/respacc/responsive-tabs.css" rel="stylesheet"> 
        <!-- Theme Styles -->
        <link href="assets/css/alpha.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/css/custom.css" rel="stylesheet" type="text/css"/>
        
        <!--[if lt IE 9]>
        <script src="http://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="http://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <style>
		.sidebar-profile { padding-bottom: 2px; }
		.headerback { background-color: <?=getSetting('headerColor')?>;}
		.material-design-hamburger__layer { color: red;}
		.featmenu { padding-top: 10px; padding-bottom: 10px;}
		</style>
    </head>
    <body class="mailbox">
        <div class="loader-bg"></div>
        <div class="loader">
            <div class="preloader-wrapper big active">
                <div class="spinner-layer spinner-blue">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div><div class="gap-patch">
                    <div class="circle"></div>
                    </div><div class="circle-clipper right">
                    <div class="circle"></div>
                    </div>
                </div>
                <div class="spinner-layer spinner-spinner-teal lighten-1">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div><div class="gap-patch">
                    <div class="circle"></div>
                    </div><div class="circle-clipper right">
                    <div class="circle"></div>
                    </div>
                </div>
                <div class="spinner-layer spinner-yellow">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div><div class="gap-patch">
                    <div class="circle"></div>
                    </div><div class="circle-clipper right">
                    <div class="circle"></div>
                    </div>
                </div>
                <div class="spinner-layer spinner-green">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div><div class="gap-patch">
                    <div class="circle"></div>
                    </div><div class="circle-clipper right">
                    <div class="circle"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mn-content fixed-sidebar">
            <header class="mn-header navbar-fixed">
                <nav class="headerback darken-1">
                    <div class="nav-wrapper row">
                       <section class="material-design-hamburger navigation-toggle">
                            <a href="#" data-position="right" data-delay="50" data-tooltip="<?=$LANG['Click to show/hide main menu']?>" data-activates="slide-out" class="button-collapse show-on-large material-design-hamburger__icon tooltipped">
                                <span class="material-design-hamburger__layer"></span>
                            </a>
                        </section> 
                        <div class="header-title col s4 m5 l5">      
                            <span id="page-title" class="chapter-title"></span>
                        </div>
                        
                        <ul class="right col s8 m7 l7 nav-right-menu">
                            <li><a data-position="bottom" data-delay="50" data-tooltip="<?=$LANG['Click to manage your account']?>" href="javascript:void(0)" data-activates="chat-sidebar" class="chat-button show-on-large tooltipped"><i class="fa fa-user-circle"></i>- <mad class="hide-on-med-and-down"><?=$LANG['My Account']?></mad></a></li>
                            <li class="hide-on-small-and-down"><a href="notification" class="dropdown-button dropdown-right show-on-large"><i class="material-icons">notifications_none</i><?php if(countNotice($userID)>0) { ?><span class="badge"><?=countNotice($userID)?></span><?php } ?></a></li>
                        </ul>
                    </div>
                </nav>
            </header>

<?php	
} //end user loggedin

