<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$resellerID = getReseller();
if( getUser() > 0) {
	if(isAdmin(getUser())) {
	//load admin menu
?>
            <aside id="chat-sidebar" class="side-nav white">
                <div class="side-nav-wrapper">
                    <div class="sidebar-profile">
                        <div class="sidebar-profile-image">
                            <img src="files/temp/<?=userData($userID,'photo')?>" class="circle" alt="">
                        </div>
                        <div class="sidebar-profile-info">
                           <span id="user-log"><?=$LANG['Hi']?> <?=userData($userID,'first_name').' '.userData($userID,'last_name')?></span>
                        </div>
                    </div>
                                       
                    <div id="sidebar-more-tab" class="col s12 sidebar-more right-sidebar-panel">
                        <a href="aprofile"><div class="setting-text"><?=$LANG['Account Settings']?></div></a>
                        <a href="alog"><div class="setting-text"><?=$LANG['Event Log']?></div></a>
                        <?php global $hooks;$hooks->do_action('AddMenuAccount');?>
                        <a href="index.php?logout"><div class="setting-text"><?=$LANG['Sign Out']?></div></a>
                    </div>
                </div>
            </aside>
			<!-- end right side enu-->
            
            <aside id="slide-out" class="side-nav white fixed" >
                <ul class="sidebar-menu collapsible collapsible-accordion" data-collapsible="accordion">
                	<?php global $hooks;$hooks->do_action('AddMenuMainBefore');?>
                    <li class="no-padding"><a class="waves-effect waves-grey" href="index.php"><i class="material-icons">home</i> <?=$LANG['Dashboard']?></a></li>
                    <hr>
                    <li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons">drafts</i> <?=$LANG['Messaging']?><i class="nav-drop-icon material-icons">keyboard_arrow_right</i></a>
                        <div class="collapsible-body">
                            <ul>
                            <?php if(userRole()<3) { ?>
                                <li><a href="acompose?t=sms"><?=$LANG['Compose']?></a></li>
                                <li><a href="adraft"><?=$LANG['Draft Messages']?></a></li>
                            <?php } ?>    
                                <li><a href="ascheduled"><?=$LANG['Scheduled Messages']?></a></li>
                                <li><a href="asent"><?=$LANG['Message History']?></a></li>
                            <?php if(userRole()<3) { ?>    
                                <li><a class="inboxes" href="ainbox"><?=$LANG['Inbox']?></a></li>
                                <li><a href="smschat"><?=$LANG['SMS Chat']?></a></li>
                            <?php } ?>    
                            	<?php global $hooks;$hooks->do_action('AddMenuMainCompose');?>
                            </ul>
                        </div>
                    </li>
					<?php if(userRole()<3) { ?>
                    <li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons">contacts</i> <?=$LANG['Contacts']?><i class="nav-drop-icon material-icons">keyboard_arrow_right</i></a>
                        <div class="collapsible-body">
                            <ul>
                                <li><a href="aphonebook"><?=$LANG['Address Book']?></a></li>
                                <li><a href="amarketinglist"><?=$LANG['Marketing List']?></a></li>
                                <li><a href="ablacklist"><?=$LANG['Blacklist']?></a></li>
                                <?php global $hooks;$hooks->do_action('AddMenuMainContact');?>
                            </ul>
                        </div>
                    </li>
                    <?php } ?>
                    <?php if(userRole()<3 || userRole()==11) { ?>
                    <li class="no-padding"><a class="waves-effect waves-grey" href="acustomer"><i class="material-icons">person_pin</i> <?=$LANG['Customers']?></a></li>
                    <?php } ?> 
                    <li class="no-padding"><a class="waves-effect waves-grey" href="atransaction"><i class="material-icons">monetization_on</i> <?=$LANG['Transactions']?></a></li>
					
                    <li class="no-padding"><a class="rttichte2 waves-effect waves-grey" href="aticket"><i class="material-icons">question_answer</i> <?=$LANG['Support Tickets']?></a></li>
                     
                     <li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons">widgets</i> <?=$LANG['More']?><i class="nav-drop-icon material-icons">keyboard_arrow_right</i></a>
                        <div class="collapsible-body">
                            <ul>
                            	<?php if(userRole()< 3) { ?>
                                <li><a href="aeport"><?=$LANG['SMS Reports']?></a></li>
                                <li><a href="asenderid"><?=$LANG['Sender ID']?></a></li>
                                <li><a href="ashortcodes"><?=$LANG['Shortcodes']?></a></li>
                                <li><a href="aapis"><?=$LANG['API']?></a></li>
                                <?php global $hooks;$hooks->do_action('AddMenuMainExtras');?>
                                <?php } ?>
                                <?=loadModules(1)?>
                            </ul>
                        </div>
                    </li>
                    <?php global $hooks;$hooks->do_action('AddMenuMainAfterExtra');?>
                    <?php if(userRole()< 3) { ?>
					<hr>
                    <li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons">dashboard</i> <?=$LANG['Tools']?><i class="nav-drop-icon material-icons">keyboard_arrow_right</i></a>
                        <div class="collapsible-body">
                            <ul>
                            	<li><a href="pushnotice"><?=$LANG['Push Notifications']?></a></li>
                                <li><a href="sendemail"><?=$LANG['Send Email']?></a></li>
								<?php if(userRole()==1) { ?>
                                <li><a href="abackup"><?=$LANG['Backup Manager']?></a></li>
                                <?php } ?>
                                <li><a href="abanned?i"><?=$LANG['Banned IPs']?></a></li>
                                <li><a href="abanned?e"><?=$LANG['Banned Emails']?></a></li>
                                <li><a href="abanned?s"><?=$LANG['Banned Sender IDs']?></a></li>
                                <li><a href="abanned?c"><?=$LANG['Banned Countries']?></a></li>
                                <li><a href="abanned?w"><?=$LANG['Banned Words']?></a></li>
                                <?php if(userRole()==1) { ?>
                                <li><a href="amodule"><?=$LANG['Module Manager']?></a></li>
                                <li><a target="_blank" href="http://sendroidultimate.ynetinteractive.com"><?=$LANG['Help']?></a></li>
                                <?php } ?>
                                <?php global $hooks;$hooks->do_action('AddMenuMainTools');?>
                            </ul>
                        </div>
                    </li>
                    <?php } ?>
                    <?php if(userRole()==1) { ?>
                    <li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons">settings_input_component</i> <?=$LANG['Settings']?><i class="nav-drop-icon material-icons">keyboard_arrow_right</i></a>
                        <div class="collapsible-body">
                            <ul>
                                <li><a href="setting?gen"><?=$LANG['General Settings']?></a></li>
                                <li><a href="setting?notic"><?=$LANG['SMS/Email Notifications']?></a></li>
                                <li><a href="customfields"><?=$LANG['Custom Fields']?></a></li>
                                <li><a href="currency"><?=$LANG['Currencies']?></a></li>
                                <li><a href="setting?rate"><?=$LANG['SMS Rates']?></a></li>
                                <li><a href="setting?pack"><?=$LANG['SMS Plans']?></a></li>
                                <li><a href="setting?vouc"><?=$LANG['SMS Vouchers']?></a></li>
                                <li><a href="smsetting?sms"><?=$LANG['SMS Gateways']?></a></li>
                                <li><a href="smsetting?rout"><?=$LANG['SMS Routing Rules']?></a></li>
                                <li><a href="auto"><?=$LANG['Automation']?></a></li>
                                <li><a href="paysetting?pay"><?=$LANG['Payment Gateways']?></a></li>
                                <li><a href="user"><?=$LANG['Administrators']?></a></li>
                                <li><a href="info"><?=$LANG['System Information']?></a></li>
                                <li><a href="alog"><?=$LANG['Access Log']?></a></li>
                                <?php global $hooks;$hooks->do_action('AddMenuMainSetting');?>
                            </ul>
                        </div>
                    </li>
                    <?php } ?>

                   <?php global $hooks;$hooks->do_action('AddMenuMainAfter');?>
                   <li class="no-padding"><a class="waves-effect waves-grey" href="?logout"><i class="material-icons">power_settings_new</i> <?=$LANG['Logout']?></a></li>
                </ul>
            </aside>
			
            <div class="mailbox-bg"></div>
            <main class="mn-inner inner-active-sidebar">    
            <div class="row" style="display: none;">
               <div class="col s12">
                   <div class="page-title"></div>
                </div>        
            </div>           
<?php	
	} else {
	//Load user menu
	$billingModel = checkBillingModel($userID);
?>
            <aside id="chat-sidebar" class="side-nav white">
                <div class="side-nav-wrapper">
                    <div class="sidebar-profile">
                        <div class="sidebar-profile-image">
                            <img src="files/temp/<?=userData($userID,'photo')?>" class="circle" alt="">
                        </div>
                        <div class="sidebar-profile-info">
                           <span id="user-log"><?=$LANG['Hi']?> <?=userData($userID,'first_name').' '.userData($userID,'last_name')?></span>
                           <h5><?=$billingModel=='unit'?'':userCurrencySymbol($userID)?><?=number_format(userWalletBalance($userID),userCurrencyZero($userID))?></h5>
                        </div>
                    </div>
                                       
                    <div id="sidebar-more-tab" class="col s12 sidebar-more right-sidebar-panel">
                    	<a href="fund"><div class="setting-text"><?=$billingModel=='unit'?$LANG['Buy SMS Units']:$LANG['Buy SMS Credits']?></div></a>
                        <a href="profile"><div class="setting-text"><?=$LANG['Account Settings']?></div></a>
                        <a href="notification"><div class="setting-text"><?=$LANG['Notifications']?></div></a>
                        <a href="log"><div class="setting-text"><?=$LANG['My Activities']?></div></a>
                        <?php global $hooks;$hooks->do_action('AddMenuAccount');?>
                        <?php if(isset($_SESSION['manageUser']) && $_SESSION['manageUser']>0) {?>
                        <a href="index.php?exituser"><div class="setting-text"><?=$LANG['Exit']?></div></a>
                        <?php } else {?>
                        <a href="index.php?logout"><div class="setting-text"><?=$LANG['Sign Out']?></div></a>
                        <?php }?>
                    </div>
                </div>
            </aside>
			<!-- end right side enu-->
            
            <aside id="slide-out" class="side-nav white fixed" >
                <ul class="sidebar-menu collapsible collapsible-accordion" data-collapsible="accordion">
	                <?php global $hooks;$hooks->do_action('AddMenuMainBefore');?>
                    <li class="no-padding"><a class="waves-effect waves-grey" href="index.php"><i class="material-icons">home</i> <?=$LANG['Dashboard']?></a></li>
					<li class="no-padding"><a class="waves-effect waves-grey" href="fund"><i class="material-icons">shopping_cart</i> <?=$billingModel=='unit'?$LANG['Buy SMS Units']:$LANG['Buy Credits']?></a></li>
                    <hr>
                    <li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons">mode_edit</i> <?=$LANG['Compose']?><i class="nav-drop-icon material-icons">keyboard_arrow_right</i></a>
                        <div class="collapsible-body">
                            <ul>
                                <?php if(getSetting('TextEnabled',0)>0){?><li><a href="compose?t=sms"><?=$LANG['Text']?></a></li><?php }?>
								<?php if(getSetting('unicodeEnabled',0)>0){?><li><a href="compose?t=unicode"><?=$LANG['Unicode']?></a></li><?php }?>
                                <?php if(getSetting('voiceEnabled',0)>0){?><li><a href="compose?t=voice"><?=$LANG['Voice']?></a></li><?php } ?>
                                <?php if(getSetting('watsappEnabled',0)>0){?><li><a href="compose?t=whatsapp"><?=$LANG['WhatsApp']?></a></li><?php } ?>
                                <?php if(getSetting('mmsEnabled',0)>0){?><li><a href="compose?t=mms"><?=$LANG['MMS']?></a></li><?php } ?>
                                <?php if(getSetting('flashEnabled',0)>0){?><li><a href="compose?t=flash"><?=$LANG['Flash']?></a></li><?php } ?>
                                <?php global $hooks;$hooks->do_action('AddMenuMainCompose');?>
                            </ul>
                        </div>
                    </li>
                    <?php if(getSetting('2wayEnabled',0)>0){?>
                    <li class="no-padding"><a class="inboxes waves-effect waves-grey" href="inbox"><i class="material-icons">inbox</i> <?=$LANG['Inbox']?> <?=showInboxCount(getUser())?></a></li>
                    <li class="no-padding"><a class="waves-effect waves-grey" href="smschat"><i class="material-icons">chat</i> <?=$LANG['SMS Chat']?> </a></li>
					<?php }?>
					<li class="no-padding"><a class="waves-effect waves-grey" href="draft"><i class="material-icons">drafts</i> <?=$LANG['Draft Messages']?></a></li>
                    <li class="no-padding"><a class="waves-effect waves-grey" href="scheduled"><i class="material-icons">watch_later</i> <?=$LANG['Scheduled Messages']?></a></li>
					<li class="no-padding"><a class="waves-effect waves-grey" href="sent"><i class="material-icons">history</i> <?=$LANG['Message History']?></a></li>
                    <li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons">contacts</i> <?=$LANG['My Contacts']?><i class="nav-drop-icon material-icons">keyboard_arrow_right</i></a>
                        <div class="collapsible-body">
                            <ul>
                                <?php if( !isResold($userID) && (getSetting('saleContactEnabled',0)>0) ){?><li><a href="buycontact"><?=$LANG['Buy Contacts']?></a></li><?php } ?>
                                <li><a href="phonebook"><?=$LANG['My Address Book']?></a></li>
                                <li><a href="marketinglist"><?=$LANG['My Marketing List']?></a></li>
                                <li><a href="blacklist"><?=$LANG['Blacklist']?></a></li>
                                <?php global $hooks;$hooks->do_action('AddMenuMainContact');?>
                            </ul>
                        </div>
                    </li>
                    <li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons">widgets</i> <?=$LANG['More']?><i class="nav-drop-icon material-icons">keyboard_arrow_right</i></a>
                        <div class="collapsible-body">
                            <ul>
                                <li><a href="pricing"><?=$LANG['SMS Coverage & Pricing']?></a></li>
                                <li><a href="report"><?=$LANG['SMS Reports']?></a></li>
                                <?php if(getSetting('dynamicSenderEnabled',0)<1){?><li><a href="senderid"><?=$LANG['Sender ID']?></a></li><?php } ?>
                                <?php if(getSetting('2wayEnabled',0)>0){?><li><a href="shortcodes"><?=$LANG['My Shortcodes']?></a></li><?php } ?>
                                <?php if(getSetting('affiliateEnabled',0)>0){?><li><a href="affiliate"><?=$LANG['Affiliates']?></a></li><?php } ?>
                                <?php if(getSetting('shareCreditEnabled',0)>0){?><li><a href="share"><?=$LANG['Transfer Credit']?></a></li><?php } ?>
                                <li><a href="apis"><?=$LANG['API']?></a></li>
                                <?php global $hooks;$hooks->do_action('AddMenuMainExtra');?>
                                <!--Custom Modules-->
                                <?=loadModules(4)?>
                            </ul>
                        </div>
                    </li>
                    <?php global $hooks;$hooks->do_action('AddMenuMainAfterExtra');?>
                    <hr>
                    <?php if(userRole()==3) { ?>
                    <li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons">security</i> <?=$LANG['Reseller Menu']?><i class="nav-drop-icon material-icons">keyboard_arrow_right</i></a>
                        <div class="collapsible-body">
                            <ul>
                                <li><a href="rcustomer"><?=$LANG['My Customers']?></a></li>
                                <li><a href="sendemail"><?=$LANG['Send Email']?></a></li>
                                <li><a class="rttichte" href="rticket"><?=$LANG['Support Tickets']?></a></li>
                                <li><a href="rtransaction"><?=$LANG['Transactions']?></a></li>
                                <li><a href="rsent"><?=$LANG['SMS History']?></a></li>
                                <li><a href="rsetting"><?=$LANG['Reseller Settings']?></a></li>
                                <?php global $hooks;$hooks->do_action('AddMenuMainReseller');?>
                                <!--Custom Modules-->
                                <?=loadModules(4)?>
                            </ul>
                        </div>
                    </li>
                    <?php } ?>
					<li class="no-padding"><a class="waves-effect waves-grey" href="transaction"><i class="material-icons">monetization_on</i> <?=$LANG['My Transactions']?></a></li>
					<li class="no-padding"><a class="rttichte2 waves-effect waves-grey" href="ticket"><i class="material-icons">question_answer</i> <?=$LANG['My Support Tickets']?></a></li>
                   <?php global $hooks;$hooks->do_action('AddMenuMainAfter');?>
                </ul>
            </aside>
			
            <div class="mailbox-bg"></div>
            <main class="mn-inner inner-active-sidebar" >    
            <div class="row" style="display: none;">
               <div class="col s12">
                   <div class="page-title"></div>
                </div>        
            </div>
<?php }		
}