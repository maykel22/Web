<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
# ---------------------------------------------------------------------
#  Add all footer scripts here
#  You are not permitted to modify the first 15 lines. Please keep off
#----------------------------------------------------------------------
global $URL; global $userID; global $LAST_NOTICE; global $LANG; $resellerID = getReseller(); global $server; ?>		
   <!-- Javascripts -->
   <script src="assets/plugins/jquery/jquery-2.2.0.min.js"></script>
   <script src="assets/plugins/materialize/js/materialize.min.js"></script>
   <script src="assets/plugins/material-preloader/js/materialPreloader.min.js"></script>
   <script src="assets/plugins/jquery-blockui/jquery.blockui.js"></script>
   <!-- Please Do Note Modify or Remove THis Line. You will loose your liocense if you do so!!! Sendroid Ultimate is developed, owned and solely licensed by Ynet Interactive.-->

   <!--Load page specific scripts--->
   <script src="assets/plugins/simditor/scripts/module.js"></script>
   <script src="assets/plugins/simditor/scripts/hotkeys.js"></script>
   <script src="assets/plugins/simditor/scripts/uploader.js"></script>
   <script src="assets/plugins/simditor/scripts/simditor.js"></script>

   <?php if($URL=='dashboard' || $URL=='adashboard' || $URL=='sent' || $URL=='report' || $URL=='aeport'  || $URL=='rsent' || $URL=='asent') { ?>
    <script src="assets/plugins/chart.js/chart.min.js"></script>
    <script src="assets/plugins/flot/jquery.flot.min.js"></script>
    <script src="assets/plugins/flot/jquery.flot.time.min.js"></script>
    <script src="assets/plugins/flot/jquery.flot.symbol.min.js"></script>
    <script src="assets/plugins/flot/jquery.flot.resize.min.js"></script>
    <script src="assets/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="assets/plugins/curvedlines/curvedLines.js"></script>
    <script src="assets/plugins/peity/jquery.peity.min.js"></script>
    <script src="assets/plugins/raphael/raphael.min.js"></script>
    <script src="assets/plugins/morris.js/morris.min.js"></script>
   <?php } ?>
   <?php if($URL=='compose' || $URL=='acompose' || $URL=='rticket' || $URL=='aticket' || $URL=='shortcodes' || $URL=='senderid' || $URL=='asenderid' || $URL=='rcustomer' || $URL=='rsetting' || $URL=='setting' || $URL=='smsetting' || $URL=='paysetting' || $URL=='profile' || $URL=='aprofile' || $URL=='aphonebook' || $URL=='amarketinglist' || $URL=='acustomer' || $URL=='ashortcodes' || $URL=='abanned' || $URL=='smsetting' || $URL=='sendemail' || $URL=='user' || $URL=='fund') { ?>
     <script src="assets/plugins/jquery-inputmask/jquery.inputmask.bundle.js"></script>
     <script src="assets/plugins/select2/js/select2.min.js"></script>
   <?php } ?>
   <?php if($URL=='rsetting' || $URL=='pricing' || $URL=='setting' || $URL=='smsetting' || $URL=='abanned') { ?>
     <script src="assets/plugins/respacc/responsiveTabs.js"></script>
     <script>
		$(document).ready(function() {
			RESPONSIVEUI.responsiveTabs();
		})
	 </script>
   <?php } ?>
   <script src="assets/js/alpha.min.js"></script>
	<script src="assets/plugins/sweetalert/sweetalert.min.js"></script>
<?php
$jsadds = "?1";
if(isset($_GET['view'])) {
	$jsadds .= "&view=".$_GET['view'];
}
if(isset($_GET['ti'])) {
	$jsadds .= "&ti=".$_GET['ti'];
}
if(isset($_GET['gwid'])) {
	$jsadds .= "&gwid=".$_GET['gwid'];
}
if(isset($_GET['v'])) {
	$jsadds .= "&v=".$_GET['v'];
}
if(isset($_GET['setting'])) {
	$jsadds .= "&setting=".$_GET['setting'];
}
if(isset($_GET['err'])) {
	$jsadds .= "&err=".$_GET['err'];
}
if(isset($_GET['confirm'])) {
	$jsadds .= "&confirm=".$_GET['confirm'];
}
if($URL =="dashboard" || $URL == "adashboard") {
	$jsadds = "";
	$queryString = (isset($_SERVER['HTTPS'])?"https":"http")."://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	$queryString = explode('?',$queryString);
	$queryString = @$queryString[1];
	if(!empty($queryString)) {
		$jsadds = "?".$queryString;
	}
}
?>        
<?php $_SESSION['TITLE'] = TITLE; $_SESSION['sLAST_NOTICE'] = $LAST_NOTICE; $_SESSION['sURL'] = $URL;?>    <script type="text/javascript" src="assets/js.php<?=$jsadds?>"></script>
    <?php    global $hooks; $hooks->do_action('CustomJavaScripts');   ?>
    </body>
</html>

<?php if($_SESSION['lasturl']!=$URL) { $_SESSION['lasturl']=$URL;  $_SESSION['lasttitle']=TITLE ;} mysqli_close($server);
?>