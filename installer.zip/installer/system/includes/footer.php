<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
# ---------------------------------------------------------------------
#  Add all footer HTML here
#  We strongly advise you do not change lines 12 - 27. 
#----------------------------------------------------------------------
global $URL; global $userID; global $LAST_NOTICE; global $LANG; $resellerID = getReseller(); global $server; ?>		
 <div id="update-spin" style="display: none;overflow-x: hidden; width: 99.99%; height: 99.99%; z-index: 99999; position: fixed; top: 0; left: 0; background: rgba(0,0,0,0.7);">
   	 <div class="row"><br><br>
       	<div class="col s1 m2 l3"> </div>
        <div class="col s10 m8 l6"><h3 class="white-text"><i class="fa fa-spinner fa-spin"></i> System update in progress...</h3> </div>
        <div class="col s1 m2 l3"> </div>
      </div>
 </div>       
        
           <div id="compose-btn" class="fixed-action-btn" style="bottom: 20px; right: 24px;">
               <a data-position="left" data-delay="50" data-tooltip="<?=$LANG['Compose New Message']?>" class="btn-floating btn-large waves-effect waves-light red tooltipped" href="compose" >
                   <i class="material-icons">mode_edit</i>
               </a>
           </div>
       </main>
        <div class="page-footer">
            <div class="footer-grid container">
                <div class="footer-l white">&nbsp;</div>
                <div class="footer-grid-l white">
                    <a class="footer-text" href="<?=@$_SESSION['lasturl']?>">
                        <i class="material-icons arrow-l">arrow_back</i>
                        <span class="direction">Previous</span>
                        <div><?=@$_SESSION['lasttitle']?></div>
                    </a>
                </div>
                <div class="footer-r white">&nbsp;</div>
            </div>
        </div>       
   </div>
   <div class="left-sidebar-hover"></div>
   <?php    global $hooks; $hooks->do_action('CustomFooterEvents');   ?>